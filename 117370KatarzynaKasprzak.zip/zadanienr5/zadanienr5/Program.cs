﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
namespace LAB_5
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] lines = File.ReadAllLines("plik_testowy.txt");
            List<List<int>> neighborhoodList = new List<List<int>>();
            for (int i = 1; i < lines.Length; i++)
            {
                String line = lines[i];
                String[] valuesInLine = line.Split(" ");
                List<int> list = new List<int>();
                foreach (String value in valuesInLine)
                {
                    int val = Int32.Parse(value);
                    list.Add(val);
                }
                neighborhoodList.Add(list);
            }

            for (int i = 0; i < neighborhoodList.Count; i++)
            {
                String value = "L[" + i + "]= ";
                List<int> row = neighborhoodList.ElementAt(i);
                for (int j = 0; j < row.Count; j++)
                {
                    value += row.ElementAt(j) + " ";
                }
                Console.WriteLine(value);
            }
            int count = neighborhoodList.Count;
            int[,] neighborhoodMatrix = new int[count, count];
            for (int i = 0; i < neighborhoodList.Count; i++)
            {
                List<int> nodeList = neighborhoodList.ElementAt(i);
                for (int j = 0; j < nodeList.Count; j++)
                {
                    int element = nodeList.ElementAt(j);
                    neighborhoodMatrix[i, element] = 1;
                }
            }

            String columnHeader = "";
            for (int i = 0; i < neighborhoodMatrix.GetLength(0); i++)
            {
                columnHeader += "\t" + i;
            }
            Console.WriteLine(columnHeader + "\n");
            for (int i = 0; i < neighborhoodMatrix.GetLength(0); i++)
            {
                String rowText = i + "";
                for (int j = 0; j < neighborhoodMatrix.GetLength(0); j++)
                {
                    rowText += "\t" + neighborhoodMatrix[i, j];
                }
                Console.WriteLine(rowText);
            }

        }
    }
}

