﻿using System;
using System.IO;

namespace Dijkstra
{
    class Program
    {
        const int MaximumValue = Int32.MaxValue;

        class Element
        {
            public int v;
            public int w;
            public Element next;
            public Element() { }
            public Element(int v, int w, Element next)
            {
                this.v = v;
                this.w = w;
                this.next = next;
            }
        }

        static void Main(string[] args)
        {
            String[] readedLines = File.ReadAllLines("test.txt");
            String firstLine = readedLines[0];
            String[] splitedFirstLine = firstLine.Split(" ");
            int v = Int32.Parse(splitedFirstLine[0]);
            int n = Int32.Parse(splitedFirstLine[1]);
            int m = Int32.Parse(splitedFirstLine[2]);
            bool[] QS = new bool[n];
            int[] d = new int[n];
            int[] p = new int[n];
            int[] S = new int[n];
            Element[] graf = new Element[n];
            int sptr = 0;

            for (int i = 0; i < n; i++)
            {
                d[i] = MaximumValue;
                p[i] = -1;
                QS[i] = false;
                graf[i] = null;
            }

            for (int i = 1; i <= m; i++)
            {
                String line = readedLines[i];
                String[] splitedLine = line.Split(" ");
                int x = Int32.Parse(splitedLine[0]);
                int y = Int32.Parse(splitedLine[1]);
                int w = Int32.Parse(splitedLine[2]);
                Element next = graf[x];
                Element el = new Element(y, w, next);
                graf[x] = el;
            }
            d[v] = 0;
            int u;
            int j;
            
            for (int i = 0; i < n; i++)
            {
                for (j = 0; QS[j]; j++) ;
                for (u = j++; j < n; j++)
                {
                    if (!QS[j] && (d[j] < d[u]))
                    {
                        u = j;
                    }
                }
                
                QS[u] = true;
              
                Element pw = graf[u];
                while (pw != null)
                {
                    if (!QS[pw.v] && (d[pw.v] > d[u] + pw.w))
                    {
                        d[pw.v] = d[u] + pw.w;
                        p[pw.v] = u;
                    }
                    pw = pw.next;
                }

            }
            for (int i = 0; i < n; i++)
            {
                String line = "";
                line = i + ":";
                for (j = i; j > -1; j = p[j]) S[sptr++] = j;
                while (sptr > 0)
                {
                    line = line + S[--sptr] + " ";
                }
                line = line + "$" + d[i];
                Console.WriteLine(line);
            }
        }
    }
}
