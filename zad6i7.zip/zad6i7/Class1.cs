﻿using System;
using System.Collections.Generic;
using System.IO;

namespace zad6i7
{
	public class Main
	{
		public static void Mainn(string[] args)
		{
			Graph g = new Graph("input.txt");

			Console.WriteLine(string.Format("Number of nodes: {0:D}", g.NumberOfNodes));
			Console.WriteLine("Graph definition:");
			for (int i = 0; i < g.Edges.Length; ++i)
			{
				Console.Write(i);
				foreach (int element in g.Edges[i])
				{
					Console.Write(" " + element);
				}
				Console.WriteLine("");
			}
			Console.WriteLine(string.Format("Graph matrix of neighborhood:\n{0}", g.NeighborhoodMatrix).ToString().Replace("], [", "]\n[").Replace("[[", "[").Replace("]]", "]"));

			g.DFS(0);
			g.BFS(0);
		}
	}
	public class Graph
	{
		private LinkedList<int>[] edges;
		private int numberOfNodes;
		private List<List<int>> neighborhoodMatrix = new List<List<int>>();

		internal Graph(string filePath)
		{
			parseFile(filePath);
			generateNeighborhoodMatrix();
		}

		public virtual List<List<int>> NeighborhoodMatrix
		{
			get
			{
				return neighborhoodMatrix;
			}
		}

		public virtual LinkedList<int>[] Edges
		{
			get
			{
				return edges;
			}
		}

		public virtual int NumberOfNodes
		{
			get
			{
				return numberOfNodes;
			}
		}

		public void generateNeighborhoodMatrix()
		{

			for (int i = 0; i < numberOfNodes; ++i)
			{
				List<int> line = new List<int>();
				for (int j = 0; j < numberOfNodes; ++j)
				{
					if (edges[i].Contains(j))
					{
						line.Add(1);
					}
					else
					{
						line.Add(0);
					}
				}
				neighborhoodMatrix.Add(line);
			}
		}

		public virtual void parseFile(string filePath)
		{
			StreamReader reader;
			try
			{
				reader = new StreamReader(filePath);
				string line = reader.ReadLine();
				numberOfNodes = Convert.ToInt32(line);
				edges = new LinkedList<int>[numberOfNodes];
				for (int i = 0; i < numberOfNodes; ++i)
				{
					edges[i] = new LinkedList<int>();
				}
				line = reader.ReadLine();
				while (!string.ReferenceEquals(line, null))
				{
					List<int> line_elements = new List<int>();
					string separator = " ";
					string[] pair = line.Split(new string[] { " " }, StringSplitOptions.None);
					addEdge(Convert.ToInt32(pair[0]), Convert.ToInt32(pair[1]));
					line = reader.ReadLine();
				}
				reader.Close();
			}
			catch (IOException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
			}
		}

		public virtual void addEdge(int x, int y)
		{
			edges[x].AddLast(y);
		}

		public virtual void nextDFSStep(int node, bool[] visited)
		{
			visited[node] = true;
			Console.WriteLine(string.Format("Visiting node {0:D}", node));

			IEnumerator<int> i = edges[node].GetEnumerator();
			while (i.MoveNext())
			{
				int n = i.Current;
				if (!visited[n])
				{
					nextDFSStep(n, visited);
				}
			}
		}

		public virtual void DFS(int node)
		{
			Console.WriteLine("DFS");
			Console.WriteLine(string.Format("node {0:D}", node));
			bool[] visited = new bool[numberOfNodes];
			nextDFSStep(node, visited);
		}

		public virtual void BFS(int node)
		{
			Console.WriteLine("BFS");
			Console.WriteLine(string.Format(" node {0:D}", node));
			bool[] visited = new bool[numberOfNodes];
			LinkedList<int> queue = new LinkedList<int>();
			visited[node] = true;
			queue.AddLast(node);

			while (queue.Count != 0)
			{
				node = queue.First.Value;
				queue.RemoveFirst();
				Console.WriteLine(string.Format("node {0:D}", node));
				IEnumerator<int> i = edges[node].GetEnumerator();
				while (i.MoveNext())
				{
					int n = i.Current;
					if (!visited[n])
					{
						visited[n] = true;
						queue.AddLast(n);
					}
				}
			}
		}
	}
}
