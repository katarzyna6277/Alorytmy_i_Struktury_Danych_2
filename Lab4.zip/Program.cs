﻿using System;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;

namespace lab4_json
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Tworzenie listy obiektów");
            Car[] cars = new Car[] {
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),
                new Car("Volksvagen", "a", "b", "c"),

            };
            var jsonCars = JsonConvert.SerializeObject(cars);
            File.WriteAllText("cars.json", jsonCars);
            var serialized = File.ReadAllText("Cars.json");
            List<Car> CarList = JsonConvert.DeserializeObject<List<Car>>(serialized);
            Console.WriteLine("Wypisanie listy obiektów");
            foreach(var car in CarList)
            {
                Console.WriteLine(car.ToString());
            }
        }
    }
}
