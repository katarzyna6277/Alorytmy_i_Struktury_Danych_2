﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab4_json
{
    class Car
    {
        public Car(string name, string model, string type, string color)
        {
            Name = name;
            Model = model;
            Type = type;
            Color = color;
        }
        public String Name { get; set; }
        public String Model { get; set; }
        public String Type { get; set; }
        public String Color { get; set; }



        public override string ToString()
        {
            return "Car name: " + this.Name + "\n\tModel: " + this.Model + "\n\tColor: " + this.Color + "\n\tType: " + this.Type;
        }
    }
}
